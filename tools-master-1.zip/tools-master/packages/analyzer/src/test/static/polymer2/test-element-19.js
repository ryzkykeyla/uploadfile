/**
 * @customElement test-element
 * @polymer
 */
class TestElement extends HTMLElement {
}
