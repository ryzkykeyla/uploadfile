/**
 * @polymer
 * @mixinFunction
 * @memberof Polymer
 */
function TestMixin() {
}
