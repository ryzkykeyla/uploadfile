// TODO(rictic): the path for the element should probably be element.html,
// but the sourceRange for the element should be element.js.

// my-element!
Polymer({is: 'my-element'});