/**
 * @namespace ExplicitlyNamedNamespace
 */
var ExplicitlyNamedNamespace = {};

/**
 * @namespace ExplicitlyNamedNamespace.NestedNamespace
 */
ExplicitlyNamedNamespace.NestedNamespace = {
  foo: 'bar'
};