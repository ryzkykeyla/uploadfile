/**
 * I have a template type.
 * @global
 * @template T
 */
function templateFn() { }

/**
 * I have 3 template types.
 * @global
 * @template A, B
 * @template
 * @template C
 */
function multiTemplateFn() { }
