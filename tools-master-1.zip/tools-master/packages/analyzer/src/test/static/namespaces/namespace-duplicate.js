/**
 * This is a duplicate of a namespace definition in `namesapce-named.js`
 *
 * @namespace ExplicitlyNamedNamespace
 */
var DuplicateNamespace = {};