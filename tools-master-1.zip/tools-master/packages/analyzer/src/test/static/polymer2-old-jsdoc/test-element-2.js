/**
 * @polymerElement
 */
class TestElement extends HTMLElement {
  static get is() {
    return 'test-element';
  }
}
