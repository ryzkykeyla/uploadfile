// This should not work
class Bar extends Foo {

}
