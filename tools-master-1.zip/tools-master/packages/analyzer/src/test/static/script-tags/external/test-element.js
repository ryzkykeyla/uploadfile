Polymer({
  is: 'test-element',
  behaviors: [TestBehavior],
});
