import * as test from 'test-package';
import * as test2 from 'test-package/index';
