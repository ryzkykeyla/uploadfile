export class Foo {}

export {Foo as FooAlias};

class Bar {}

export {Bar};
