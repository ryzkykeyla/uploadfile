import { subThing } from './submodule.js';
export const otherValue = subThing;
