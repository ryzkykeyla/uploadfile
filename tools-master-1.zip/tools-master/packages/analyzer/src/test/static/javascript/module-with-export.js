export const someValue = 'value goes here';
