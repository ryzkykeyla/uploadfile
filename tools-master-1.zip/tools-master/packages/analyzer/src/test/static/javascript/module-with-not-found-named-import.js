import * as test from 'foo-bar';
