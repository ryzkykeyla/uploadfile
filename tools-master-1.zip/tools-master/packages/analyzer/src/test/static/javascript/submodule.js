export const subThing = 'sub-thing';
