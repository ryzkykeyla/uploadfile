export const namedConstIdentifier = 10;

export default 100;

export class ClassName { };

export function functionName() { };

export const identifierAssignedFunction = function funcExpressionName() { };

export const [a, b, c = 10, ...d] = [1, 2, 3, 5, 6, 7];

export const { g, h: i, j: k = l } = lol;

export { someValue as anotherValue } from './module-with-export.js';

export * from './module-with-export-and-default-export.js';
