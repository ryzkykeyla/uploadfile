import * as submodule from './submodule.js';

import * as foo from './does-not-exist.js';
