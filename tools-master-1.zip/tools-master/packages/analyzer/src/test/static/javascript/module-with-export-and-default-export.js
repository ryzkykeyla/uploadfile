export const someValue = 'value goes here';
const defaultValue = 'default value';
export { defaultValue as default };
