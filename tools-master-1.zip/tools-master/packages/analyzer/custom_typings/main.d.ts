/// <reference path="./babel.d.ts" />
/// <reference path="./chai.d.ts" />
/// <reference path="./indent.d.ts" />
/// <reference path="./knuth-shuffle.d.ts" />
/// <reference path="./strip-indent.d.ts" />
