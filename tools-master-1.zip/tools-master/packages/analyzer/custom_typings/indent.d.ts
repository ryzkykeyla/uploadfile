
declare module 'indent' {
  function indent(text: string, margin?: number|string): string;
  export = indent;
}
