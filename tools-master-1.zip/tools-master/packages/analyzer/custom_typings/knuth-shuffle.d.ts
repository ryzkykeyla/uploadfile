declare module 'knuth-shuffle' {
  /** Does an in-place shuffle of the given array. */
  export function knuthShuffle(arr: Array<any>): void;
}
