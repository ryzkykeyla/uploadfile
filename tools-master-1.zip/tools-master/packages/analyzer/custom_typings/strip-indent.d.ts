
declare module 'strip-indent' {
  function stripIndent(text: string): string;
  export = stripIndent;
}
