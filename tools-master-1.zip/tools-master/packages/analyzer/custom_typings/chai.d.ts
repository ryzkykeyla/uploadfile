declare module Chai {
  interface Assert {
    containSubset(act: any, exp: any, msg?: string): void;
  }
}
