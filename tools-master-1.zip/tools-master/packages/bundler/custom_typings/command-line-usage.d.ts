declare module 'command-line-usage' {
  function commandLineUsage(args: any)
      : string;
  module commandLineUsage {
    
  }
  export = commandLineUsage;
}
