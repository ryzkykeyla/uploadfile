console.log('hello from /absolute-paths/script.js');
