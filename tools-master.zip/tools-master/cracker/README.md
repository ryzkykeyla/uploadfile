# About
Tools for cracking network and software login masks. Not been able to find an
exploit to give you RCE? Too lazy to SE? So go smash down the front doors and
rummage around with our cracking and brute force tools.

If you find some bugs or if you have any questions, ideas or criticism regarding
to this section, feel free to message us.

# Disclaimer
We hereby emphasize, that the hacking related stuff on
[nullsecurity.net](http://nullsecurity.net) is only for education purposes.
We are not responsible for any damages. You are responsible for your own
actions.
