# Description
against.py is a very fast ssh attacking script which includes a multithreaded
port scanning module (tcp connect) for discovering possible targets and a
multithreaded brute-forcing module which attacks parallel all discovered hosts
or given ip addresses from a list.

# Author
pgt

# Disclaimer
We hereby emphasize, that the hacking related stuff on
[nullsecurity.net](http://nullsecurity.net) is only for education purposes.
We are not responsible for any damages. You are responsible for your own
actions.
