# Description
sshtrix is a very fast multithreaded SSH login cracker. It supports SSHv1 and
SSHv2. sshtrix was designed to automate rapid bruteforce attacks against SSH
authentification screens. Unlike other public tools, the aim is to keep it
simple, stable, fast and modular. With its clean code design, it is easy to
extend the code to a framework or to fork it against protocols of your choice.

# Author
noptrix

# Disclaimer
We hereby emphasize, that the hacking related stuff on
[nullsecurity.net](http://nullsecurity.net) is only for education purposes.
We are not responsible for any damages. You are responsible for your own
actions.
