# About
Why wireless? It works and you don't have to wear your favorite nullsecurity
hoody to hide you face from the camera in reception. Hack all the thingz!

If you find some bugs or if you have any questions, ideas or criticism regarding
to this section, feel free to message us.

# Disclaimer
We hereby emphasize, that the hacking related stuff on
[nullsecurity.net](http://nullsecurity.net) is only for education purposes.
We are not responsible for any damages. You are responsible for your own
actions.
