# Description
hwk is an easy-to-use wireless authentication and deauthentication tool.
Furthermore, it also supports probe response fuzzing, beacon injection flooding,
antenna alignment and various injection testing modes. Information gathering is
selected by default and shows the incoming traffic indicating the packet types.

# Author
atzeton

# Disclaimer
We hereby emphasize, that the hacking related stuff on
[nullsecurity.net](http://nullsecurity.net) is only for education purposes.
We are not responsible for any damages. You are responsible for your own
actions.
