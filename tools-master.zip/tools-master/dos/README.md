# About
(D)DoS tools if you wanna by like those n00bs at anonymous or simulate everyones
favourite underground extortionists.

If you find some bugs or if you have any questions, ideas or criticism regarding
to this section, feel free to message us.

# Disclaimer
We hereby emphasize, that the hacking related stuff on
[nullsecurity.net](http://nullsecurity.net) is only for education purposes.
We are not responsible for any damages. You are responsible for your own
actions.
