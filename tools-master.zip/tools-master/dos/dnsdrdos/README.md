# Description
Proof of concept code that demonstrates a distributed DNS reflection denial of
service attack.

# Author
noptrix

# Disclaimer
We hereby emphasize, that the hacking related stuff on
[nullsecurity.net](http://nullsecurity.net) is only for education purposes.
We are not responsible for any damages. You are responsible for your own
actions.
