# About
Encrypt all the things! With privacy issues moving up most people agenda with
items like PRISM in the news cryptography it one of todays hot topics. It's also
pretty useful for exfiltrating data from your target environment, connecting to
that C2 box and keeping your loot away from prying eyes.

If you find some bugs or if you have any questions, ideas or criticism regarding
to this section, feel free to message us.

# Disclaimer
We hereby emphasize, that the hacking related stuff on
[nullsecurity.net](http://nullsecurity.net) is only for education purposes.
We are not responsible for any damages. You are responsible for your own
actions.
