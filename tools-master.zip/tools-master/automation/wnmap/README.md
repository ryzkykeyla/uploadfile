# Description
A shell script written with the purpose to automate and chain scans via nmap.
You can run nmap with a custom mode written by user and create directories for
every mode with the xml/nmap files inside.

# Author
nrz

# Disclaimer
We hereby emphasize, that the hacking related stuff on
[nullsecurity.net](http://nullsecurity.net) is only for education purposes.
We are not responsible for any damages. You are responsible for your own
actions.
