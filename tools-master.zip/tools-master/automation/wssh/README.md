# Description
A shell script written with the purpose to automate jumps between boxes via ssh
forgetting about IPs, Users, Ports and so on. You can set your host list at
/home/${USER}/.wssh/wssh.conf file and start ssh'ing boxes, executing automated
commands, or downloading/uploading files just using name/id associated.

# Author
nrz

# Disclaimer
We hereby emphasize, that the hacking related stuff on
[nullsecurity.net](http://nullsecurity.net) is only for education purposes.
We are not responsible for any damages. You are responsible for your own
actions.
