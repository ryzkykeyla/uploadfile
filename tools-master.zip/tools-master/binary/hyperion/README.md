# Description
Hyperion is a runtime encrypter for 32/64 bit portable executables. It is a
reference implementation and bases on the paper "Hyperion: Implementation of a
PE-Crypter".

# Author
belial

# Disclaimer
We hereby emphasize, that the hacking related stuff on
[nullsecurity.net](http://nullsecurity.net) is only for education purposes.
We are not responsible for any damages. You are responsible for your own
actions.
