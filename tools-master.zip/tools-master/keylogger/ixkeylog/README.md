# Description
iXKeylog is a X11 keylogger for Unix that basically uses xlib to interact
with users keyboard. iXkeylog will listen for certain X11 events and then
trigger specific routines to handle these events.

# Author
Cyneox

# Disclaimer
We hereby emphasize, that the hacking related stuff on
[nullsecurity.net](http://nullsecurity.net) is only for education purposes.
We are not responsible for any damages. You are responsible for your own
actions.
