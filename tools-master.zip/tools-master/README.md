# About
This section offers a selection of our fully featured security and hacking tools.
We also provide some exploits, proof of concept code, shellcodes and snippets.
That means some tools are not tested and may not have the feature set.

If you find some bugs or if you have any questions, ideas or criticism regarding
to this section, feel free to message us.

# Disclaimer
We hereby emphasize, that the hacking related stuff on
[nullsecurity.net](http://nullsecurity.net) is only for education purposes.
We are not responsible for any damages. You are responsible for your own
actions.
