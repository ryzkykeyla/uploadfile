# Description
Atari 2600 Homebrew which can be played with a Lightgun (PAL and NTSC)

# Author
belial

# Disclaimer
We hereby emphasize, that the hacking related stuff on
[nullsecurity.net](http://nullsecurity.net) is only for education purposes.
We are not responsible for any damages. You are responsible for your own
actions.
