# Description
Simple trainer which patches "The Legend of Zelda" for Famicom/NES. After usage
each item in the NPC shops is for free.

# Author
belial

# Disclaimer
We hereby emphasize, that the hacking related stuff on
[nullsecurity.net](http://nullsecurity.net) is only for education purposes.
We are not responsible for any damages. You are responsible for your own
actions.
