# Description
A tool aimed at visualizing (network) data. It provides more or less tools and
libraries to visualize your data regardless of its type. You can easily use it
for network analysis but also for representing data in a fancy way. Due to its
simplicity and cross-platform aspect you can use it almost everywhere. All you
need is a ... browser :)

# Author
Cyneox

# Disclaimer
We hereby emphasize, that the hacking related stuff on
[nullsecurity.net](http://nullsecurity.net) is only for education purposes.
We are not responsible for any damages. You are responsible for your own
actions.
