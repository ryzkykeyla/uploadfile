# Description
Arduino sketch which maps the buttons of a Sega Genesis controller
to the Amiga game port. Supports three and six button gamepads and
provides autofire. Can be used to build an adapter which enables
you to buy new Sege Genesis gamepad replicas and connect them to
your Amiga or C64.

# Author
belial

# Disclaimer
We hereby emphasize, that the hacking related stuff on
[nullsecurity.net](http://nullsecurity.net) is only for education purposes.
We are not responsible for any damages. You are responsible for your own
actions.
