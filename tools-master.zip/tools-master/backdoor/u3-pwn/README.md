# Description
U3-Pwn is a tool designed to automate injecting executables to Sandisk smart usb
devices with default U3 software install. This is performed by removing the
original iso file from the device and creating a new iso with autorun features.

# Author
Zy0d0x

# Disclaimer
We hereby emphasize, that the hacking related stuff on
[nullsecurity.net](http://nullsecurity.net) is only for education purposes.
We are not responsible for any damages. You are responsible for your own
actions.
