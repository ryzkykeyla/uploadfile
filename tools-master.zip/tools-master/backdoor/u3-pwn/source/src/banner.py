#!/usr/bin/python
# -*- coding: utf-8 -*-
try:
    import os
except ImportError, error:
    print'\n[-]Failed To Import Module\n'
    print error


def print_banner():
    os.system('clear')
    print '''
                                                                              
        ~    .__ \xc2\xb0.__   0       o                    ^   .__ \xc2\xb0__  `\xc2\xb4        
 \xc2\xb0____) __ __|  | | \xc2\xb0|   ______\xc2\xb0____ 0 ____  __ _________|__|/  |_ ___.__.  
 /    \\|  | \xc2\xb0\\  |\xc2\xb0|  | \xc2\xb0/  ___// __ \\_/ ___\\|  | \xc2\xb0\\_  __ \\ o\\   __<   |  |  
| o\xc2\xb0|  \\  |  /  |_|  |__\\___ \\  ___/\\ \xc2\xb0\\___| o|  /|  | \\/  ||  |\xc2\xb0 \\___ O|  
|___|  /____/|____/____/____ \xc2\xb0>\\___  >\\___  >____/ |__|\xc2\xb0 |__||__|  / ____|  
`\xc2\xb4\xc2\xb4`\xc2\xb4\\/\xc2\xb4`nullsecurity team`\xc2\xb4\\/`\xc2\xb4\xc2\xb4`\xc2\xb4\\/`\xc2\xb4``\xc2\xb4\\/  ``\xc2\xb4```\xc2\xb4```\xc2\xb4\xc2\xb4\xc2\xb4\xc2\xb4`\xc2\xb4``0_o\\/\xc2\xb4\xc2\xb4`\xc2\xb4\xc2\xb4  

 ************************************************************************
      U3-Pwn  Metasploit Payload Injection Tool For SanDisk Devices
 ************************************************************************
'''


