# Description
This tool stores up to 426 bytes in the MBR's bootloader code section of unused
devices such as usb drivers, hrd disks (which are not supposed to boot) and
other media. GRUB detection is implemented for safety reasons, Windows
bootloader code will be shamelessly overwritten. ;)

# Author
atzeton

# Disclaimer
We hereby emphasize, that the hacking related stuff on
[nullsecurity.net](http://nullsecurity.net) is only for education purposes.
We are not responsible for any damages. You are responsible for your own
actions.
