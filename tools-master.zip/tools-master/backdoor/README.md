# About
Backdoors and rootkits for kernel and userland, network, hardware and software.
Once you have gone through all the hard work making sure you can get on the
system. Make sure you can always get back in.

If you find some bugs or if you have any questions, ideas or criticism regarding
to this section, feel free to message us.

# Disclaimer
We hereby emphasize, that the hacking related stuff on
[nullsecurity.net](http://nullsecurity.net) is only for education purposes.
We are not responsible for any damages. You are responsible for your own
actions.
