# Description
UniOFuzz - the universal fuzzing tool for browsers, web services, files,
programs and network services/ports.

# Author
pgt

# Disclaimer
We hereby emphasize, that the hacking related stuff on
[nullsecurity.net](http://nullsecurity.net) is only for education purposes.
We are not responsible for any damages. You are responsible for your own
actions.
