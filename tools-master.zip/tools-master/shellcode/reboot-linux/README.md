# Description
reboot(0x1234567);

# OS
Linux

# Arch
x86

# Size
21 bytes

# Author
noptrix

# Disclaimer
We hereby emphasize, that the hacking related stuff on
[nullsecurity.net](http://nullsecurity.net) is only for education purposes.
We are not responsible for any damages. You are responsible for your own
actions.
