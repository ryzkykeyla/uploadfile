# About
Just because our fuzzer worked or the PoC was fantastic doesn't mean that
running calc is gonna put a smile on your face. If you got RCE try our
shellcodes to actually do something useful.

If you find some bugs or if you have any questions, ideas or criticism regarding
to this section, feel free to message us.

# Disclaimer
We hereby emphasize, that the hacking related stuff on
[nullsecurity.net](http://nullsecurity.net) is only for education purposes.
We are not responsible for any damages. You are responsible for your own
actions.
