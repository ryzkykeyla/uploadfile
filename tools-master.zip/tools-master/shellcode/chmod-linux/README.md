# Description
chmod("/etc/shadow", 666); exit();

# OS
Linux

# Arch
x86

# Size
32 bytes

# Author
noptrix

# Disclaimer
We hereby emphasize, that the hacking related stuff on
[nullsecurity.net](http://nullsecurity.net) is only for education purposes.
We are not responsible for any damages. You are responsible for your own
actions.
