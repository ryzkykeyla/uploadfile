# About
Can't find any useful hints on shodan? Google dorks not dishing up the goods?
Hell get one of our scanners out and track down your targets in 2 shakes of a
lol-cat's tail.

If you find some bugs or if you have any questions, ideas or criticism regarding
to this section, feel free to message us.

# Disclaimer
We hereby emphasize, that the hacking related stuff on
[nullsecurity.net](http://nullsecurity.net) is only for education purposes.
We are not responsible for any damages. You are responsible for your own
actions.
