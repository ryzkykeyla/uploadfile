# Description
Nasty creature constantly searching for DNS servers. It uses standard dns querys
and waits for the replies.

# Author
atzeton

# Disclaimer
We hereby emphasize, that the hacking related stuff on
[nullsecurity.net](http://nullsecurity.net) is only for education purposes.
We are not responsible for any damages. You are responsible for your own
actions.
