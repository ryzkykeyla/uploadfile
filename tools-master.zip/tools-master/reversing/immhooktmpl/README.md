# Description
Due to the lack of documentation for Immnunity API this is an easy template for
function hooking while reversing.

# Author
nrz

# Disclaimer
We hereby emphasize, that the hacking related stuff on
[nullsecurity.net](http://nullsecurity.net) is only for education purposes.
We are not responsible for any damages. You are responsible for your own
actions.
