<?php

namespace PHPUnityo;

class PHPUnityoNoApiTokenError extends \Exception
{
}
