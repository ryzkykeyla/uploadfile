<?php
$loader = require __DIR__.'/../vendor/autoload.php';
$loader->addPsr4('PHPUnityo\\', __DIR__.'/PHPUnityo');
